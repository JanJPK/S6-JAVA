﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace s6_java_1_data
{
    class Program
    {
        private static string[] firstNames = new[] {"Zygmunt", "Stefan", "Karol", "Tomasz","Piotr","Jan","Joanna","Krystyna","Wiktoria","Dorota","Karolina"};
        private static string[] lastNames = new[] {"Bobek", "Wons", "Goldberg", "Gegen", "Kowal", "Passat", "Kopacz", "Drwal"};
        private static Random rng = new Random();
        static void Main(string[] args)
        {
            
            int dataAmount = Convert.ToInt32(Console.ReadLine());
            int questionAmount = Convert.ToInt32(Console.ReadLine());
            int questionChoices = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Generating {dataAmount} test results of {questionAmount} question test with {questionChoices} yes/no answers in a question.");
            for (int i = 0; i < dataAmount; i++)
            {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < questionAmount; j++)
                {
                    for (int k = 0; k < questionChoices; k++)
                    {
                        sb.Append(rng.Next() % 2 == 0 ? "0" : "1");
                        if (k < questionChoices - 1)
                            sb.Append(",");
                    }
                    sb.Append(Environment.NewLine);
                }

                int randomFirstName = rng.Next(firstNames.Length);
                int randomLastName = rng.Next(lastNames.Length);
                int id = 226000 + i;
                string filename = $"{id}_{firstNames[randomFirstName]}_{lastNames[randomLastName]}.csv";

                using (StreamWriter sw = new StreamWriter("data\\" + filename))
                {
                    sw.Write(sb.ToString());
                }
            }

            Console.WriteLine("Done.");
            Console.ReadKey();
        }
    }
}
